### Changelog

## Version 1.0.0 (5 March 2019)

## Version 1.1.0 (6 April 2021)

## Version 1.1.0 (17 May 2021)

## Version 2.0.0 (03 Mar 2022)
- Updated to React 17
- Added react-app-rewired
- updated to Bootstrap 5
- updated to Reactstrap 9
- Updated all Libraries